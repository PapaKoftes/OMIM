# Non-Goals & Out-of-Scope Boundaries

Version: v0.1.0  
Section: 01_FOUNDATION  

See also: [[01_FOUNDATION/Vision_and_Scope]], [[01_FOUNDATION/Manufacturing_Domain_Lock]]

---

## Purpose

This document explicitly enumerates what OMIM is NOT trying to do. Non-goals are as important as goals — they prevent scope creep, prevent misleading claims, and keep the project focused.

**Rule**: Any feature request, design decision, or implementation that touches a non-goal item must be rejected or deferred to a post-v0 milestone.

---

## System Non-Goals (OMIM Is NOT)

| OMIM Is NOT | Why This Matters |
|-------------|-----------------|
| A CAM system | We do not generate G-code or toolpaths |
| A chatbot wrapper | There is no LLM at the center of this system |
| An autonomous machining AI | We do not control machines or make manufacturing decisions |
| A universal CAD format converter | We parse DXF for v0; other formats are extension points |
| A production-certified system | This is research infrastructure, not industrial software |
| A replacement for human machinists | It is a reasoning aid, not a human replacement |
| A simulation system | No physics simulation, no FEA, no toolpath simulation |
| A nesting optimizer | Nesting is recognized but not optimized in v0 |
| An ERP/MES system | No production scheduling, no inventory management |
| A real-time controller | No machine communication in v0 |

---

## Technical Non-Goals (v0 Only)

### What Validation Does NOT Cover

OMIM v0.1 validation is geometric manufacturability approximation. It explicitly does NOT validate:

| Not Validated | Why |
|-------------|-----|
| Fixturing adequacy | Requires machine knowledge, tooling, part weight |
| Tool deflection | Requires FEA / physics simulation |
| Machine rigidity | Machine-specific, dynamic analysis required |
| Material behavior | Chipload, tearout, moisture variation — material science |
| Operation ordering | Requires process planning domain knowledge |
| Feeds and speeds | Machine-specific; cannot infer from DXF |
| Coolant / chip evacuation | Machine and pocket-geometry dependent |
| Thermal effects | Requires heat transfer modeling |

A panel that passes OMIM validation may still fail to machine correctly in a specific shop with specific tooling. A panel that fails OMIM validation should be treated as a strong warning, not a certainty of failure.

---

## Manufacturing Domain Non-Goals (v0)

These domains are explicitly out of scope for v0 and must NOT be implemented:

| Out of Scope | Why |
|-------------|-----|
| 5-axis machining | Different constraint model entirely |
| Waterjet / laser / plasma cutting | Different physics, different rules |
| 3D printing / additive manufacturing | Fundamentally different domain |
| Robotic manufacturing | Requires motion planning, kinematics |
| Sheet metal forming | Bending, forming, punching — different ontology |
| G-code generation | Full CAM scope — separate product |
| Toolpath simulation | Physics simulation, out of budget |
| CAM toolpath optimization | Requires deep CAM knowledge |
| Multi-machine coordination | Scheduling problem, separate domain |
| Edge banding / post-processing | Post-routing operations; not representable in 2D DXF |
| STP/STEP/IGES format support | Additional parsers, not needed for v0 |
| Solid wood grain anisotropy | Material complexity beyond panel-grade composites |

---

## Architecture Non-Goals (v0)

### Prohibited During Hackathon
- Distributed systems or microservices
- Kubernetes, Docker Swarm, or container orchestration
- Cloud databases (SQLite, JSON files, or Parquet only)
- Authentication or authorization systems
- Real-time streaming pipelines
- Production deployment hardening
- Horizontal scaling infrastructure

### Prohibited Claims
- "OMIM validates real-world manufacturability" — it validates against programmed rules
- "OMIM can identify all manufacturing features" — only ontology v0.1.0 features are detectable
- "OMIM outputs can be used directly for CNC programming" — human review required
- "Synthetic data matches real manufacturing data distribution" — domain gap is expected
- "Models trained on synthetic data deploy to production" — research infrastructure only

---

## Ontology Non-Goals

The v0.1.0 ontology intentionally does NOT cover:

- Assembly context (how panels connect to each other)
- Tolerance stack-up analysis
- Material grain direction effects
- Fixturing or workholding
- Economic cost modeling
- Time/cycle analysis
- Quality control inspection features

Adding these would require a fundamentally different data model than what DXF provides.

---

## ML Non-Goals

- OMIM does not train production-grade manufacturing AI models
- OMIM does not claim to replace domain expert judgment
- OMIM does not use LLMs for manufacturing reasoning (LLMs hallucinate manufacturing facts)
- OMIM does not train models on proprietary shop data without explicit permission

---

## Post-Hackathon Extension Points (Architecture Must Support, Not Implement)

The architecture must NOT hardcode furniture-only assumptions. Abstraction boundaries must be clean enough that a new domain can be added by:
1. Adding a new ontology YAML file
2. Adding new validator rules
3. Adding a new parser module

Without touching core infrastructure. These are extension points, not v0 deliverables.
