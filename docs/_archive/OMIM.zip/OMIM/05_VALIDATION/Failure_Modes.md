# Failure Mode Specification

Version: v0.1.0  
Section: 05_VALIDATION  

See also: [[03_INTERFACES/Parser_Interface]], [[03_INTERFACES/Validation_Interface]], [[10_IMPLEMENTATION/Definition_of_Done]]

---

## Purpose

Specifies how OMIM behaves for every identifiable failure case. No failure is silent. Every failure produces a structured output.

---

## Failure Categories

### Category A: File System Failures

| Failure | Module | Behavior | Fatal? |
|---------|--------|---------|--------|
| DXF file not found | Parser | Raise `FileNotFoundError` with path | Yes |
| DXF file not readable (permissions) | Parser | Raise `PermissionError` | Yes |
| Output directory not writable | Exporter | Raise `ExportIOError` | Yes (for that sample) |
| Rules YAML file missing | Rule Engine | Raise `RuleLoadError` | Yes (engine cannot start) |
| Ontology YAML file missing | Semantic Layer | Raise `OntologyLoadError` | Yes |

---

### Category B: DXF Parse Failures

| Failure | Code | Behavior | Recoverable? |
|---------|------|---------|-------------|
| File exceeds 50MB | `DXF_TOO_LARGE` | Return `ParseResult(success=False)` | No |
| Corrupt/malformed DXF | `DXF_CORRUPT` | Return `ParseResult(success=False)` | No |
| Unsupported DXF version (pre-AC1015) | `DXF_VERSION_UNSUPPORTED` | Return `ParseResult(success=False)` | No |
| Empty DXF (no entities) | warning: `empty_file` | Return `RawGeometry` with empty entities | Yes (warning) |
| Unknown entity type | warning: `entity_skipped` | Skip entity; add warning to RawGeometry | Yes (warning) |
| Inches detected | warning: `units_converted` | Convert to mm; continue | Yes (warning) |
| No panel boundary detected | warning: `no_panel_boundary` | Infer from bounding box + 10mm margin | Yes (warning) |
| Block INSERT entity | warning: `block_insert` | Explode if simple; else skip | Yes (warning) |

---

### Category C: MGG Build Failures

| Failure | Behavior | Fatal? |
|---------|---------|--------|
| `RawGeometry` with `parse_result.success=False` | Raise `MGGBuildError("parse failed")` | Yes |
| Entity with no geometry coordinates | Skip entity; log warning | No |
| Shapely geometry computation exception | Skip node spatial relationships; log error | No |
| Panel boundary detection ambiguous (multiple candidates) | Use largest closed contour; log warning | No |

---

### Category D: Validation Failures

These are not system errors — they are expected outputs for invalid geometry.

| Condition | Output |
|-----------|--------|
| GEO-001 open contour | `RuleResult(rule_id="GEO-001", severity="ERROR")` |
| MFG-001 edge clearance violation | `RuleResult(rule_id="MFG-001", severity="ERROR")` |
| Any Layer 1 ERROR | `ValidationReport(layer1_passed=False, overall_valid=False)` |
| Any Layer 2 ERROR | `ValidationReport(layer2_passed=False, overall_valid=False)` |
| Rule evaluation exception (any rule) | `RuleResult(severity="SYSTEM_ERROR", message=str(e))` |
| Rule execution timeout >10s | `RuleResult(severity="SYSTEM_ERROR", message="timeout")` |

**SYSTEM_ERROR results do not cause overall_valid=False unless explicitly required by operator policy.** They indicate the rule could not be evaluated, not that the geometry is invalid.

---

### Category E: Semantic Layer Failures

| Failure | Behavior | Fatal? |
|---------|---------|--------|
| `layer1_passed=False` when semantic layer called | Raise `SemanticPreconditionError` | Yes |
| Ontology version mismatch | Log warning; continue with loaded ontology | No |
| Node unclassifiable | `FeatureAnnotation(feature_class="UNKNOWN_FEATURE", confidence=0.0)` | No |
| Inference engine exception (per node) | Log error; mark node as UNKNOWN_FEATURE | No |
| All nodes unclassifiable | Return `SemanticAnnotations` with 100% UNKNOWN_FEATURE | No |

---

### Category F: Export/Schema Failures

| Failure | Behavior | Fatal? |
|---------|---------|--------|
| `validate_sample_schema()` fails | Raise `ExportValidationError`; no files written | Yes (for that sample) |
| Partial write failure (disk full mid-write) | Delete partial temp dir; raise `ExportIOError` | Yes (for that sample) |
| `mgg.to_json()` raises exception | Log error; raise `SerializationError` | Yes (for that sample) |
| `ValidationReport.model_dump_json()` fails | This should not happen (Pydantic invariant); raise unconditionally | Yes |

---

### Category G: Pipeline Orchestration Failures

```python
class PipelineResult(BaseModel):
    success: bool
    stage_reached: Literal["parse", "mgg_build", "validation", "semantic", "export"]
    parse_result: ParseResult | None
    mgg: ManufacturingGeometryGraph | None
    validation_report: ValidationReport | None
    annotations: SemanticAnnotations | None
    export_result: ExportResult | None
    errors: list[PipelineError]
    total_time_ms: float

class PipelineError(BaseModel):
    stage: str
    error_type: str
    message: str
    recoverable: bool
```

| Failure | Behavior |
|---------|---------|
| Fatal error in any stage | Set `success=False`; record in `errors`; stop pipeline |
| Non-fatal warning in any stage | Continue; append to `errors` with `recoverable=True` |
| Unhandled exception | Catch at pipeline level; wrap in PipelineError; never propagate raw exception to caller |

---

## Forbidden Anti-Patterns

```python
# FORBIDDEN: Silent failure
try:
    result = validate_mgg(mgg)
except Exception:
    pass  # NEVER swallow exceptions silently

# FORBIDDEN: String errors
return "error: something went wrong"  # NEVER return error strings; use structured types

# FORBIDDEN: Partial schema output
# Either write a complete, schema-valid sample or write nothing

# FORBIDDEN: Mutable global state for error accumulation
GLOBAL_ERRORS = []  # NEVER; use PipelineResult.errors
```

---

## Escalation Policy

| Error Severity | Escalation |
|----------------|-----------|
| `RuleLoadError`, `OntologyLoadError` | Fatal — process exits; no output |
| `FileNotFoundError` | Fatal — logged; no output for that file |
| `ParseResult(success=False)` | Log to stderr; skip sample in batch |
| `SYSTEM_ERROR` in rule result | Log; include in ValidationReport; do not block |
| `ExportValidationError` | Log with field list; skip sample |

In batch processing, per-sample failures are isolated. One bad sample does not abort the batch.
