# Benchmark Tasks

Version: v0.1.0  
Section: 09_BENCHMARKS  

See also: [[09_BENCHMARKS/Evaluation_Metrics]], [[09_BENCHMARKS/Train_Test_Policy]], [[10_IMPLEMENTATION/Definition_of_Done]]

---

## Overview

OMIM v0.1.0 defines 4 benchmark tasks. All tasks evaluate against the frozen test set. Ground truth comes from synthetic generation specs (not from OMIM's own inference).

---

## BENCH-001: Feature Classification

**Goal**: Classify each geometry node into its correct feature type.

```
Task type:    Multi-class classification
Input:        ManufacturingGeometryGraph (geometry + spatial relationships)
Output:       feature_class per node (from Feature_Taxonomy)
Ground truth: labels.json feature_class (from generation spec)
```

### Classes

All 14 feature types from Feature_Taxonomy plus UNKNOWN_FEATURE:
`THROUGH_HOLE, BLIND_HOLE, SHELF_PIN_HOLE, HINGE_CUP_HOLE, CONFIRMAT_HOLE, DOWEL_HOLE, POCKET, GROOVE, DADO, RABBET, OPEN_SLOT, PROFILE_CUT, INTERNAL_CUTOUT, UNKNOWN_FEATURE`

### Evaluation

**Primary metric**: Macro F1-score (all classes equally weighted)  
**Secondary metric**: Per-class F1 for each feature type  
**Pass threshold**: Macro F1 ≥ 0.80

```python
from sklearn.metrics import f1_score

macro_f1 = f1_score(y_true, y_pred, average="macro", zero_division=0)
```

### Baseline

Rule-based semantic inference (OMIM's built-in semantic layer). Any submitted model should beat this baseline.

---

## BENCH-002: Manufacturability Prediction

**Goal**: Predict whether a panel is manufacturable (passes all validation rules).

```
Task type:    Binary classification
Input:        ManufacturingGeometryGraph
Output:       is_valid ∈ {True, False}
Ground truth: labels.json is_valid (from generation spec)
```

### Evaluation

**Primary metric**: Binary F1-score  
**Critical metric**: False Negative Rate (FNR) — predicting valid when actually invalid  
**Pass thresholds**:
- Binary F1 ≥ 0.85
- FNR ≤ 0.10 (at most 10% of invalid panels predicted as valid)

```python
from sklearn.metrics import f1_score, confusion_matrix

binary_f1 = f1_score(y_true, y_pred, pos_label=True)
tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
fnr = fn / (fn + tp)  # false negative rate
```

**FNR is critical**: Predicting a defective panel as valid is a manufacturing safety issue. FNR ≤ 0.10 is a hard requirement.

### Baseline

OMIM rule-based validation achieves FNR = 0.0 on synthetic data (it generated the violations). Any ML model should match or exceed this on held-out distributions.

---

## BENCH-003: Operation Inference

**Goal**: Infer the required manufacturing operations from geometry.

```
Task type:    Multi-label classification (a panel may need multiple operations)
Input:        ManufacturingGeometryGraph
Output:       set of operations required ∈ {DRILLING, CNC_ROUTING, PROFILE_CUTTING, NESTING}
Ground truth: FEATURE_TO_OPERATIONS mapping applied to labels.json features
```

### Ground Truth Derivation

```python
from omim.ontology import FEATURE_TO_OPERATIONS

def compute_operation_ground_truth(labels: dict) -> set[str]:
    operations = set()
    for feat in labels["features"]:
        ops = FEATURE_TO_OPERATIONS.get(feat["feature_class"], [])
        operations.update(ops)
    operations.add("NESTING")  # every panel requires NESTING consideration
    return operations
```

### Evaluation

**Primary metric**: Macro F1-score (treating each operation as a binary classification)  
**Pass threshold**: Macro F1 ≥ 0.85

```python
# Multi-label F1 computed as macro average over all 4 operation classes
operation_f1 = f1_score(y_true_multilabel, y_pred_multilabel, average="macro")
```

### Baseline

Deterministic mapping from BENCH-001 classifications to operations. BENCH-003 score is bounded by BENCH-001 accuracy.

---

## BENCH-004: Anomaly Detection

**Goal**: Detect panels with unusual or out-of-distribution geometry without prior knowledge of specific violation types.

```
Task type:    Binary classification (anomaly vs. normal)
Input:        ManufacturingGeometryGraph
Output:       anomaly_score ∈ [0.0, 1.0] (higher = more anomalous)
Ground truth: is_valid from labels.json (anomalous = invalid)
```

### Evaluation

**Primary metric**: AUROC (Area Under the ROC Curve)  
**Secondary metric**: AUPR (Area Under the Precision-Recall Curve)  
**Pass threshold**: AUROC ≥ 0.80

```python
from sklearn.metrics import roc_auc_score

auroc = roc_auc_score(y_true, anomaly_scores)
```

### Distinction from BENCH-002

BENCH-002 uses a threshold classifier; BENCH-004 uses a ranking/scoring approach. BENCH-004 tests whether a model can assign higher scores to invalid panels even without knowing the specific rules.

---

## Benchmark Submission Protocol

For each benchmark task, a submission must provide:

```python
class BenchmarkSubmission(BaseModel):
    task_id: str                  # "BENCH-001" through "BENCH-004"
    model_name: str
    predictions: list[Prediction] # one per test sample
    metadata: dict                # architecture, training config, etc.

class Prediction(BaseModel):
    sample_id: str
    # BENCH-001: dict[node_id, feature_class]
    # BENCH-002: bool
    # BENCH-003: list[str] (operation names)
    # BENCH-004: float (anomaly score)
    prediction: Any
    confidence: float | None
```

---

## Test Set Integrity

**The test set is never used for training or hyperparameter tuning.**  
See [[09_BENCHMARKS/Train_Test_Policy]] for complete policy.

Any model that shows evidence of test set contamination is disqualified.
