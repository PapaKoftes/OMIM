# Canonical Sample Schema

**Status: FROZEN**  
**Schema Version: v0.1.0**

Version: v0.1.0  
Section: 02_SCHEMA  

See also: [[02_SCHEMA/MGG_Schema]], [[02_SCHEMA/Validation_Report_Schema]], [[02_SCHEMA/Provenance_Schema]]

---

## Purpose

This document defines the exact, frozen format of one OMIM dataset sample — the atomic unit of every dataset, benchmark, and training corpus.

**Schema changes require version bump to `v0.2.0` and migration tooling.**

---

## Disk Layout (Per Sample)

```
data/synthetic/samples/sample_{id:05d}/
├── geometry.dxf          # Source DXF (geometry atom)
├── mgg.json              # Manufacturing Geometry Graph
├── validation.json       # ValidationReport
├── labels.json           # Ground truth labels
└── provenance.json       # Full pipeline provenance chain
```

**All five files are required.** A sample missing any file must NOT be included in any benchmark split.

---

## 1. `labels.json` — Ground Truth Labels

```json
{
  "$schema": "omim-labels-v0.1.0",
  "sample_id": "sample_00001",
  "schema_version": "v0.1.0",
  "is_valid": true,
  "injected_violations": [],
  "panel": {
    "width_mm": 800.0,
    "height_mm": 600.0,
    "thickness_mm": 18.0,
    "area_mm2": 480000.0,
    "material": "MDF"
  },
  "features": [
    {
      "feature_id": "feat_001",
      "feature_class": "SHELF_PIN_HOLE",
      "ontology_version": "v0.1.0",
      "diameter_mm": 5.0,
      "depth_mm": null,
      "is_through": false,
      "position_mm": [50.0, 32.0],
      "group_id": "shelf_pin_row_left",
      "geometry_entity_id": "circle_a3f2",
      "ground_truth_source": "synthetic_generator",
      "confidence": 1.0
    }
  ],
  "feature_counts": {"SHELF_PIN_HOLE": 4, "PROFILE_CUT": 1},
  "operations": ["DRILLING", "PROFILE_CUTTING"],
  "complexity": "medium",
  "split": "train"
}
```

### Required Fields

| Field | Type | Notes |
|-------|------|-------|
| `$schema` | string | Must be `"omim-labels-v0.1.0"` |
| `is_valid` | boolean | True iff passes all ERROR-level rules |
| `injected_violations` | list[string] | Rule IDs injected (empty for valid) |
| `panel.thickness_mm` | float | 18.0 default |
| `features[].feature_class` | string | Ontology v0.1.0 ID |
| `features[].position_mm` | [float, float] | [x, y] in panel coordinates |
| `features[].confidence` | float | 1.0 for synthetic ground truth |
| `split` | string | `"train"` \| `"val"` \| `"test"` |

---

## 2. `mgg.json` — Manufacturing Geometry Graph

See [[02_SCHEMA/MGG_Schema]] for the full node/edge schema.

```json
{
  "$schema": "omim-mgg-v0.1.0",
  "omim_mgg_version": "v0.1.0",
  "metadata": {
    "graph_id": "UUID",
    "spec_version": "v0.1.0",
    "ontology_version": "v0.1.0",
    "source_file": "geometry.dxf",
    "source_file_hash": "sha256:abc123...",
    "geometry_node_count": 12,
    "feature_node_count": 11,
    "creation_timestamp": "2026-05-30T14:23:05Z"
  },
  "nodes": [...],
  "links": [...]
}
```

**Invariant**: Every node must have a `provenance` field.

---

## 3. `validation.json` — ValidationReport

See [[02_SCHEMA/Validation_Report_Schema]] for the full schema.

```json
{
  "$schema": "omim-validation-v0.1.0",
  "layer1_passed": true,
  "layer2_passed": true,
  "overall_valid": true,
  "ruleset_version": "v0.1.0",
  "layer1_results": [...],
  "layer2_results": [...],
  "provenance": {"inference_method": "deterministic", "confidence": 1.0}
}
```

---

## 4. `provenance.json` — Pipeline Provenance

See [[02_SCHEMA/Provenance_Schema]] for the full schema.

```json
{
  "$schema": "omim-provenance-v0.1.0",
  "sample_id": "sample_00001",
  "pipeline_stages": [
    {"stage": "synthetic_generator", "inference_method": "synthetic", "confidence": 1.0},
    {"stage": "parser", "inference_method": "deterministic", "confidence": 1.0},
    {"stage": "graph_builder", "inference_method": "deterministic", "confidence": 1.0},
    {"stage": "validation", "inference_method": "deterministic", "confidence": 1.0},
    {"stage": "semantic", "inference_method": "heuristic", "confidence": 0.88}
  ],
  "dataset_version": "omim-synthetic-v0.1.0"
}
```

---

## 5. `geometry.dxf` — Source DXF

Requirements:
- `$INSUNITS = 4` (mm) in DXF header
- Standard layers: `CUT`, `DRILL`, `POCKET`, `BORDER`
- All Z coordinates = 0
- Reproducible from `(generation_seed, generation_config)` pair

---

## Schema Validation Function

```python
def validate_sample_schema(sample_dir: str) -> list[str]:
    """Returns list of violations (empty = valid)."""
    errors = []
    for fname in ["geometry.dxf", "mgg.json", "validation.json", "labels.json", "provenance.json"]:
        if not Path(f"{sample_dir}/{fname}").exists():
            errors.append(f"MISSING FILE: {fname}")
    
    labels = json.loads(Path(f"{sample_dir}/labels.json").read_text())
    if labels.get("$schema") != "omim-labels-v0.1.0":
        errors.append("labels.json: wrong $schema version")
    for i, feat in enumerate(labels.get("features", [])):
        for req in ["feature_id", "feature_class", "position_mm", "ground_truth_source", "confidence"]:
            if req not in feat:
                errors.append(f"features[{i}]: missing '{req}'")
    
    mgg = json.loads(Path(f"{sample_dir}/mgg.json").read_text())
    for node in mgg.get("nodes", []):
        if "provenance" not in node.get("data", {}):
            errors.append(f"mgg.json node {node['id']}: missing provenance")
    return errors
```

---

## Automated Consistency Checks

| Check | When | Blocking? |
|-------|------|-----------|
| `check_ontology_consistency()` | Startup | Yes |
| `check_graph_integrity()` | After each MGG build | Yes |
| `validate_sample_schema()` | Before adding to dataset | Yes |
| `check_dataset_consistency()` | After bulk generation | Yes |

---

## Version & Migration Policy

| Version | Date | Status |
|---------|------|--------|
| v0.1.0 | 2026-05-30 | Active, frozen for hackathon |

Schema changes require: version bump, migration script `tools/migrate_dataset_v{old}_to_v{new}.py`, updated validation function, changelog entry.
